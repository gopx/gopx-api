# GoHTTP

A lightweight implementation of HTTP in Golang.