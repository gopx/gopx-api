package gows

func Sum(a, b int) int {
	return a + b
}
